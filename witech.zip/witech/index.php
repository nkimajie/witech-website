<?php
include 'includes/header.php';
?>



<!--/banner-slider-->
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
			<ol class="carousel-indicators">
				<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
				<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
				<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
				<li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
			</ol>
			<div class="carousel-inner">
				<div class="carousel-item active">
					<div class="container">
						<div class="carousel-caption">

							
							<h3>We Don't Just Teach On The Board</h3>
							<p>The First Drone Practical Training School In The Region</p>
							<div class="button-4 mx-auto">
								<div class="eff-4"></div>
								<a href="#courses"> View Courses</a>
							  </div>
							
						</div>
					</div>
				</div>
				<div class="carousel-item item2">
					<div class="container">
						<div class="carousel-caption">
							<h3>One class can
								change everything.</h3>
							<p>We believe that every student is unique</p>
							<div class="button-4 mx-auto">
								<div class="eff-4"></div>
								<a href="services.html"> View Courses</a>
							  </div>
						</div>
					</div>
				</div>
				<div class="carousel-item item3">
					<div class="container">
						<div class="carousel-caption">
							<h3>Better learning
								for better results.</h3>
							<p>We believe that every student is unique</p>
							<div class="button-4 mx-auto">
								<div class="eff-4"></div>
								<a href="services.html"> View Courses</a>
							  </div>
						</div>
					</div>
				</div>
				<div class="carousel-item item4">
					<div class="container">
						<div class="carousel-caption">
							<h3>We care about the safety of our students</h3>
							<p>your health is our no.1 priority.</p>
							<div class="button-4 mx-auto">
								<div class="eff-4"></div>
								<a href="services.html"> View Courses</a>
							  </div>
						</div>
					</div>
				</div>
			</div>
			<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a>
		</div>

	</div>
	<!--//banner-slider-->

</section>
<!-- //w3l-banner-slider-main -->

<section class="w3l-features-1">
	<!-- /features-1-->
	<div class="features-1-mian py-5">
		<div class="container py-lg-5">
			<!-- /title-->
			<div class="row title-content">
				<div class="col-lg-4 title-left">
					<h3 class="hny-title">What do you want to Learn today?</h3>
				</div>
				<div class="col-lg-8 title-info">
					<p>Learning is the process of acquiring new understanding, knowledge, behaviors, skills, values, attitudes, and preferences.</p>
				</div>
			</div>
			<!-- //title-->
			<!-- /grids-->
			<div class="row grids-innf my-lg-5">
				<div class="features-1-info col-lg-3 col-md-6">
					<div class="features-1-info-icon">
						<span class="fa fa-user"></span>
					</div>
					<div class="features-1-info-info">
						<h6><a href="#">Experienced Instructors</a></h6>
						<p>our Instructors are Experienced and qualified.</p>
					</div>

				</div>
				<div class="features-1-info col-lg-3 col-md-6">
					<div class="features-1-info-icon">
						<span class="fa fa-book"></span>
					</div>
					<div class="features-1-info-info">
						<h6><a href="#">Modern Learning</a></h6>
						<p>flexible classroom spaces with integrate technologies.</p>
					</div>

				</div>
				<div class="features-1-info col-lg-3 col-md-6">
					<div class="features-1-info-icon">
						<span class="fa fa-thumbs-o-up"></span>
					</div>
					<div class="features-1-info-info">
						<h6><a href="#">100% Improvement</a></h6>
						<p>we help you inprove in all fileds.</p>
					</div>

				</div>
				<div class="features-1-info col-lg-3 col-md-6">
					<div class="features-1-info-icon">
						<span class="fa fa-trophy"></span>
					</div>
					<div class="features-1-info-info">
						<h6><a href="#">Our Achievements</a></h6>
						<p>We have trained many students in different field and there are doing well.</p>
					</div>
				</div>
			</div>
			<!-- //grids-->
			
		</div>
	</div>
	</div>
</section>
<!-- //features-1-->
<section class="w3l-video-main">
	<!-- /video-6-->
	<div class="video-66-info">
		<div class="container-fluid">
			<div class="video-grids-info row">
				<div class="video-gd-right col-lg-8">
					<div class="video-inner history-info text-center">
								<!--popup-->
								<a href="#small-dialog" class="popup-with-zoom-anim play-view text-center position-absolute">
									<span class="video-play-icon">
									  <span class="fa fa-play"></span>
									</span>
								  </a>
					  
								  <!-- dialog itself, mfp-hide class is required to make dialog hidden -->
								  <div id="small-dialog" class="zoom-anim-dialog mfp-hide">
								  <iframe src="https://player.vimeo.com/video/440364590" width="640" height="360" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>

								  </div>
									<!--//popup-->
					      </div>
				  </div>
				<div class="video-gd-left col-lg-4 p-lg-5 p-4">
					<div class="p-xl-4 p-0 video-wrap">
						<h3 class="hny-title text-left">
						Motivated by the desire to Achieve </h3>
						<p>Find the right way to learn</p>
						<div class="button-4-pink">
							<div class="eff-4-pink"></div>
							<a href="contact.php">Contact Us</a>
						  </div>
					</div>
				</div>

			</div>
		</div>
	</div>
</section>
<!-- //video-6-->
<!-- portfolio -->

<section class="w3-gallery">
	<?php
	include 'includes/courses.php';
	?>
</section>


<!-- //portfolio -->
<section class="w3l-apply-6">
	<!-- /apply-6-->
	<div class="apply-info py-5">
		<div class="container py-lg-5">
			<div class="apply-grids-info row">
				<div class="apply-gd-left col-lg-7">
						<label>Welcome to Witech</label>
						<h4>Apply for Admission</h4>
						<!-- <p class="para-apply">It’s limited seating! Hurry up. Get the Coaching Training for Free</p> -->
					<!-- <div class="row mt-lg-5 mt-4">
						<div class="col-md-6 sub-apply mt-4">
								<div class="apply-sec-info">
										<div class="appyl-sub-icon">
											<span class="fa fa-line-chart"></span>
										</div>
										<div class="appyl-sub-icon-info">
												<h5><a href="#">Empower Teachers</a></h5>
											<p>Lorem ipsum dolor sit amet,Ea consequuntur.</p>
										</div>
					
									</div>

						</div>
						<div class="col-md-6 sub-apply mt-4">
								<div class="apply-sec-info">
										<div class="appyl-sub-icon">
											<span class="fa fa-clock-o"></span>
										</div>
										<div class="appyl-sub-icon-info">
												<h5><a href="#">Lifetime access</a></h5>
											<p>Lorem ipsum dolor sit amet,Ea consequuntur.</p>
										</div>
					
									</div>
						</div>
					</div> -->
					<?php
					if(isset($_GET['application_sucessful'])){
						echo "<script>";
						echo "alert('Application Sucessful Our Staff Will Contact You')";
						echo "</script>";
					}
					?>
				</div>
				<div class="apply-gd-right col-lg-5 mt-lg-0 mt-5">
	
					<div class="apply-form p-md-5 p-4 mx-auto bg-white mw-100">
						<form action="includes/function.php" method="post">
							<div class="form-group">
								<label>Full Name</label>

								<input type="text" class="form-control" name="a_name" id="validationDefault01" placeholder="Enter Name"
									required="">
							</div>
							<div class="form-group">
								<label>Email</label>
								<input type="email" class="form-control" name="a_email" id="validationDefault02" placeholder="abc@link.com"
									required="">
							</div>

							<div class="form-group mb-4">
								<label class="mb-2">Phone Number</label>
								<input type="text" class="form-control" name="a_phone" id="password1" placeholder="+234000000000" required="">
							</div>
							<div class="form-group">
								<label>Course Of Instrest</label>
								<select name="a_course" class="form-control" id="">
									<option value="Infotech Proficiency">Infotech Proficiency</option>
									<option value="Graphic Design">Graphic Design</option>
									<option value="Mobile & App Development">Mobile & App Development</option>
									<option value="Networking">Networking</option>
									<option value="Cyber Security">Auto Card</option>
									<option value="Cyber Security">Cyber Security</option>
									<option value="Blogging">Blogging</option>
									<option value="Digital Marketing">Digital Marketing</option>
									<option value="Solar Energy">Solar Energy</option>
									<option value="Inverter Technology">Inverter Technology</option>
									<option value="cctv">CCTV</option>
								</select>
							</div>

							<button type="submit" name="apply" class="btn btn-primary submit">Apply Now</button>

						</form>

					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- //apply-6-->

<section class="w3l-customers-6">
	<!--/customers -->
	<div class="customers-6-infhny py-5">
		<div class="container py-lg-5">

				<div class="row title-content mb-5">
						<div class="col-lg-4 title-left">
							<h3 class="hny-title">Happy Students</h3>
						</div>
						<div class="col-lg-8 title-info">
							<!-- <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae eligendi minima accusantium
								reiciendis, cupiditate optio corrupti quis quam at!.Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.</p> -->
						</div>
					</div>
				<div id="myCarousel" class="carousel slide" data-ride="carousel">
						<!-- Carousel indicators -->
						<ol class="carousel-indicators">
							<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
							<li data-target="#myCarousel" data-slide-to="1"></li>
							<li data-target="#myCarousel" data-slide-to="2"></li>
						</ol>   
						<!-- Wrapper for carousel items -->
						<div class="carousel-inner">		
							<div class="item carousel-item active">
								<div class="img-box"><img src="assets/images/c1.jpg" alt=""></div>
								<p class="testimonial">Coming to WITECH has been a huge blessing i got to learn lot of things so i am greatful.</p>
								<p class="overview"><b>Chioma Nwafor</b>Student</p>
								<div class="star-rating">
									<ul class="list-inline">
										<li class="list-inline-item"><span class="fa fa-star"></span></li>
										<li class="list-inline-item"><span class="fa fa-star"></span></li>
										<li class="list-inline-item"><span class="fa fa-star"></span></li>
										<li class="list-inline-item"><span class="fa fa-star"></span></li>
										<li class="list-inline-item"><span class="fa fa-star-o"></span></li>
									</ul>
								</div>
							</div>
							<div class="item carousel-item">
								<div class="img-box"><img src="assets/images/c2.jpg" alt=""></div>
								<p class="testimonial">Coming here has been a very big opputunity for me to gain knowlage in tech. At first i thought i won't be able to meet up, but with the help of the teachers i was able to come out as the best.</p>
								<p class="overview"><b>Eric Ebem</b>Student</p>
								<div class="star-rating">
									<ul class="list-inline">
										<li class="list-inline-item"><span class="fa fa-star"></span></li>
										<li class="list-inline-item"><span class="fa fa-star"></span></li>
										<li class="list-inline-item"><span class="fa fa-star"></span></li>
										<li class="list-inline-item"><span class="fa fa-star"></span></li>
										<li class="list-inline-item"><span class="fa fa-star-o"></span></li>
									</ul>
								</div>
							</div>
							<div class="item carousel-item">
								<div class="img-box"><img src="assets/images/c3.jpg" alt=""></div>
								<p class="testimonial">Me being in WITECH has really been instresting i have known a lot about microsoft word, power point and excel. they teachers here are really amazing they make sure you understand before you move to the next topic.</p>
								<p class="overview"><b>Joy Obot</b>Student</p>
								<div class="star-rating">
									<ul class="list-inline">
										<li class="list-inline-item"><span class="fa fa-star"></span></li>
										<li class="list-inline-item"><span class="fa fa-star"></span></li>
										<li class="list-inline-item"><span class="fa fa-star"></span></li>
										<li class="list-inline-item"><span class="fa fa-star"></span></li>
										<li class="list-inline-item"><span class="fa fa-star-half-o"></span></li>
									</ul>
								</div>
							</div>		
						</div>
						<!-- Carousel controls -->
						<a class="carousel-control left carousel-control-prev" href="#myCarousel" data-slide="prev">
							<span class="fa fa-angle-left"></span>
						</a>
						<a class="carousel-control right carousel-control-next" href="#myCarousel" data-slide="next">
							<span class="fa fa-angle-right"></span>
						</a>
					</div>
		  </div>
		<!--//customers -->
	</div>
</section>
<!-- //customers-6-->



<?php
include 'includes/footer.php';
?>