<?php
include 'includes/header2.php';
?>

<div class="container">
        <nav aria-label="breadcrumb" class="breadcrumb-info">
          <h2 class="hny-title text-center">About Us</h2>
          <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">About Us</li>
          </ol>
        </nav>
      </div>
          <!-- //breadcrumbs-->
	</div>
	<!--//banner-slider-->
</section>
<section class="w3l-wecome-content-6">
	<!-- /content-6-section -->
	  <div class="ab-content-6-mian py-5">
			 <div class="container py-lg-5">
					<div class="welcome-grids row">
							<div class="col-lg-6 mb-lg-0 mb-5">
								<h6>About Us</h6>
								<!-- <h3 class="hny-title">
									Improving Lives Through Learning
									</h3> -->
								<p class="my-4"><strong>We</strong> aim to ocupy a value portion of the industry to not only be a prefered partner to
									 in our offered product and services, but to raise our costumers minds to a high pedestral 
									 in knowlage and increase skill set so that the are not only employeble but be their own 
									 enterpreneurs in their own filed of preferences.</p>
								<p class="mb-4"><strong>We</strong> also plan to grow in the future to bridge the gap between our students and the global 
							world through distant online program with our student can attain themselves by accessing our internet
								 and studious facility.</p>
								<div class="button-4-pink">
									<div class="eff-4-pink"></div>
									<a href="contact.php"> Contact Us</a>
								  </div>
							</div>
							<div class="col-lg-6 welcome-image">
								<img src="assets/images/pic.jpg" class="img-fluid" alt="" />
							</div>	
						
						</div>	
				 
				 </div>
			 </div>
	 </section>
   <!-- //content-6-section -->

  
<section class="w3l-specification-6">
	<!-- /specification-6-->
	<div class="specification-content py-5">
		<div class="container py-lg-5">
			<div class="mission-grids-info row">
				<div class="mission-gd-left col-lg-7">
					<div class="grids-inn-ab">
						<div class="sub-mission one-top">
							<div class="mission-sec-gd">
									<img src="assets/images/p1.jpg" alt="" class="img-fluid" />
							</div>
							<div class="mission-sec-gd">
									<img src="assets/images/p2.jpg" alt="" class="img-fluid" />
							</div>

						</div>
						<div class="sub-mission">
								<div class="mission-sec-gd">
										<img src="assets/images/p6.jpg" alt="" class="img-fluid" />
								</div>
								<div class="mission-sec-gd">
										<img src="assets/images/p4.jpg" alt="" class="img-fluid" />
								</div>
	
							</div>
					</div>
				</div>
				<div class="mission-gd-right col-lg-5 pl-lg-4">

						<h3 class="hny-title">Our Mission</h3>
						<p>To bridge the gap between our students and the global world by offering professional programs and services with ease, 
							affordability, and excellence.
						</p>
				</div>
			</div>
		</div>
</section>
<!-- //specification-6-->

<section class="w3l-content-5">
	<!-- /content-6-section -->
	  <div class="content-5-main">
			 <div class="container">
					 <div class="content-info-in row">
							 <div class="content-gd col-lg-6">
									 <h3 class="hny-title two">
									
Our Vision</h3>
							 </div>
							 <div class="content-gd col-lg-6">
									<p>To occupy a valued portion of the industry and raise employable entrepreneurs, through
										high pedestal knowlage in skill set in their respective field of prefrence.
									</p>
									 <!-- <p>Lorem ipsum dolor sit amet,Ea consequuntur illum facere aperiam sequi optio consectetur adipisicing elit. Fuga, suscipit totam animi consequatur saepe blanditiis.</p> -->
									
							 </div>
							
					 </div>
				 
				 </div>
			 </div>
	 </section>
   <!-- //content-6-section -->

  
	<!--/team-sec-->
	<section class="w3l-team-main">
		<div class="team py-5">
			<div class="container py-lg-5">
					<div class="row title-content">
							<div class="col-lg-4 title-left">
								<h3 class="hny-title">Meet Our Registrar</h3>
							</div>
							<div class="col-lg-8 title-info">
								<!-- <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae eligendi minima
									accusantium
									reiciendis, cupiditate optio corrupti quis quam at!.Duis aute irure dolor in reprehenderit
									in voluptate velit esse cillum.</p> -->
							</div>
						</div>
					<div class="row team-row">
							<div class="col-lg-3 col-md-6 team-wrap">
									<div class="team-info text-center">
										<div class="column position-relative">
											<a href="#url"><img src="assets/images/team1.jpg" alt="" class="img-fluid team-image" /></a>
										</div>
										<div class="column">
											<h3 class="name-pos"><a href="#url">J . J James</a></h3>
											<p>Registrar</p>
											<!-- <div class="social">
												<a href="#facebook" class="facebook"><span class="fa fa-facebook" aria-hidden="true"></span></a>
												<a href="#twitter" class="twitter"><span class="fa fa-twitter" aria-hidden="true"></span></a>
											</div> -->
									</div>
								</div>
							</div>
							<!-- end team member -->
				
							<!-- <div class="col-lg-3 col-md-6 team-wrap">
			
									<div class="team-info text-center">
											<div class="column position-relative">
												<a href="#"><img src="assets/images/team5.jpg" alt="" class="img-fluid team-image" /></a>
											</div>
											<div class="column">
												<h3 class="name-pos"><a href="#">Joseph TeTe</a></h3>
												<p>Instructor</p> -->
												<!-- <div class="social">
													<a href="#facebook" class="facebook"><span class="fa fa-facebook" aria-hidden="true"></span></a>
													<a href="#twitter" class="twitter"><span class="fa fa-twitter" aria-hidden="true"></span></a>
												</div> -->
										<!-- </div>
									</div>
							</div> -->
							<!-- end team member -->
				
							<!-- <div class="col-lg-3 col-md-6 team-wrap">
									<div class="team-info text-center">
											<div class="column position-relative">
												<a href="#url"><img src="assets/images/team3.jpeg" alt="" class="img-fluid team-image" /></a>
											</div>
											<div class="column">
												<h3 class="name-pos"><a href="#">Takon Ajie</a></h3>
												<p>Instructor</p> -->
												<!-- <div class="social">
													<a href="#facebook" class="facebook"><span class="fa fa-facebook" aria-hidden="true"></span></a>
													<a href="#twitter" class="twitter"><span class="fa fa-twitter" aria-hidden="true"></span></a>
												</div> -->
										<!-- </div>
									</div>
								
							</div> -->
							<!-- end team member -->
							<!-- end team member -->
				
							<!-- <div class="col-lg-3 col-md-6 team-wrap">
			
									<div class="team-info text-center">
											<div class="column position-relative">
												<a href="#url"><img src="assets/images/team4.jpg" alt="" class="img-fluid team-image" /></a>
											</div>
											<div class="column">
												<h3 class="name-pos"><a href="#url">Marko Dugonji</a></h3>
												<p>Law Instructor</p>
												<div class="social">
													<a href="#facebook" class="facebook"><span class="fa fa-facebook" aria-hidden="true"></span></a>
													<a href="#twitter" class="twitter"><span class="fa fa-twitter" aria-hidden="true"></span></a>
												</div>
										</div>
									</div>
							</div> -->
							<!-- end team member -->
							<!-- <div class="col-lg-3 col-md-6 team-wrap">
									<div class="team-info text-center">
										<div class="column position-relative">
											<a href="#url"><img src="assets/images/team5.jpg" alt="" class="img-fluid team-image" /></a>
										</div>
										<div class="column">
											<h3 class="name-pos"><a href="#url">Anthony</a></h3>
											<p>Physics Instructor</p>
											<div class="social">
												<a href="#facebook" class="facebook"><span class="fa fa-facebook" aria-hidden="true"></span></a>
												<a href="#twitter" class="twitter"><span class="fa fa-twitter" aria-hidden="true"></span></a>
											</div>
									</div>
								</div>
							</div> -->
							<!-- end team member -->
				
							<!-- <div class="col-lg-3 col-md-6 team-wrap">
			
									<div class="team-info text-center">
											<div class="column position-relative">
												<a href="#url"><img src="assets/images/team6.jpg" alt="" class="img-fluid team-image" /></a>
											</div>
											<div class="column">
												<h3 class="name-pos"><a href="#url">Emma Stone</a></h3>
												<p>Maths Instructor</p>
												<div class="social">
													<a href="#facebook" class="facebook"><span class="fa fa-facebook" aria-hidden="true"></span></a>
													<a href="#twitter" class="twitter"><span class="fa fa-twitter" aria-hidden="true"></span></a>
												</div>
										</div>
									</div>
							</div> -->
							<!-- end team member -->
				
							<!-- <div class="col-lg-3 col-md-6 team-wrap">
									<div class="team-info text-center">
											<div class="column position-relative">
												<a href="#url"><img src="assets/images/team7.jpg" alt="" class="img-fluid team-image" /></a>
											</div>
											<div class="column">
												<h3 class="name-pos"><a href="#url">Rhoda Byrd</a></h3>
												<p>Finance Instructor</p>
												<div class="social">
													<a href="#facebook" class="facebook"><span class="fa fa-facebook" aria-hidden="true"></span></a>
													<a href="#twitter" class="twitter"><span class="fa fa-twitter" aria-hidden="true"></span></a>
												</div>
										</div>
									</div>
								
							</div> -->
							<!-- end team member -->
							<!-- end team member -->
				
							<!-- <div class="col-lg-3 col-md-6 team-wrap">
			
									<div class="team-info text-center">
											<div class="column position-relative">
												<a href="#url"><img src="assets/images/team8.jpg" alt="" class="img-fluid team-image" /></a>
											</div>
											<div class="column">
												<h3 class="name-pos"><a href="#url">Max Stoiber</a></h3>
												<p>History Instructor</p>
												<div class="social">
													<a href="#facebook" class="facebook"><span class="fa fa-facebook" aria-hidden="true"></span></a>
													<a href="#twitter" class="twitter"><span class="fa fa-twitter" aria-hidden="true"></span></a>
												</div>
										</div>
									</div>
							</div> -->
							<!-- end team member -->
				</div>
			</div>
	</section>
	<!--//team-sec-->
<!-- footer -->
<?php
include 'includes/footer.php';
?>
