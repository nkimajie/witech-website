<?php
include 'includes/header2.php'
?>
 <!-- /breadcrumbs-->
 <link rel="stylesheet" href="verify.css">
 <div class="container">
          <nav aria-label="breadcrumb" class="breadcrumb-info">
            <h2 class="hny-title text-center">Verify Student Certificate</h2>
            <ol class="breadcrumb mb-0">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Verify Student Certificate</li>
            </ol>
          </nav>
        </div>
            <!-- //breadcrumbs-->
            <div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-50">
				<form method="GET" action="<?php echo $_SERVER['PHP_SELF']; ?>" class="login100-form validate-form">
					<!-- <span class="login100-form-title p-b-33">
						Admin Login
					</span> -->

					<div class="wrap-input100 validate-input" >
						<input class="input100" type="text" name="v_code" placeholder="Input Verification Code">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>


					<div class="container-login100-form-btn m-t-20">
						<button name="verify" class="login100-form-btn">
							Verify
						</button>
					</div>

				</form>
				<?php 
				if(isset($_GET['v_code']))

				?> 

			</div>
			<!-- <img src="assets/images/com.png" alt="" width="300" height="300"> -->
		</div>
		
	</div>

<?php
include 'includes/footer.php';
?>