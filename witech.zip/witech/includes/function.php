<?php include "db.php"; ?>


<?php
function apply(){
    global $connection;
    
    if(isset($_POST['apply'])){
       
        $name = $_POST['a_name'];
        $email = $_POST['a_email'];
        $phone = $_POST['a_phone'];
        $course = $_POST['a_course'];

        $sql = "INSERT INTO apply(a_name, a_email, a_number, a_course) VALUES('$name', '$email', '$phone', '$course')";
        $query = mysqli_query($connection, $sql);
        
        if($query){
            header('location:../index.php?application_sucessful');
        }
    }
}
apply();

// function reg(){
//     global $connection;

    
// if(isset($_POST['register'])){
// 	$user = clean($_POST['name']);
// 	$pass = clean($_POST['pass']);

// 	$hashpass = md5($pass);
//     $sql =  "INSERT INTO admin VALUES('$user', '$hashpass')";
//     $query = mysqli_query($connection, $sql);

//     if($query){
//         header("location: ../reg.php");
//     }
// }

// function clean(){
// 	global $connection;

// 	$data = htmlspecialchars($data);
// 	$data = mysqli_real_escape_string($connection, $data);
// 	$data = stripslashes($data);
// 	$data = strip_tags($data);
// 	return $data;
// }

// }
// reg();

function contact(){
    global $connection;

    if(isset($_POST['contact'])){
        $name = $_POST['c_name'];
        $email = $_POST['c_email'];
        $num = $_POST['c_num'];
        $message = $_POST['c_message'];

        $sql = "INSERT INTO contact(c_name, c_email, c_num, c_message) VALUES('$name', '$email', '$num', '$message')";
        $result = mysqli_query($connection, $sql);

        if($result){
            header("location: ../contact.php?message_sent");
        }

    }
}
contact();