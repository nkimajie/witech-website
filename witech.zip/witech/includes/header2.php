<?php include 'db.php'; ?>
<!doctype html>
<html lang="zxx">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Whitechaple Institute Of Technology | A Whitechaple Global Company</title>
  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style-starter.css">
  <!-- Template CSS -->
  <link href="//fonts.googleapis.com/css?family=Muli:300,300i,400,500,600,700,800,900&display=swap" rel="stylesheet">
  <link href="//fonts.googleapis.com/css?family=Roboto:300,300i,400,500,700,900&display=swap" rel="stylesheet">
  <!-- Template CSS -->

</head>
<body>

<!--/top-header-content-->
<section class="w3l-top-header-content">
	<div class="hny-top-menu">
		<div class="top-hd">
			<div class="container-fluid">
				<div class="row">
					<ul class="social-top col-md-7">
						
					</ul>
					<ul class="accounts col-md-5">
						<li class="top_li"><span class="fa fa-mobile"></span><a href="tel:+234 7067860555">+234 7067860555</a>
						</li>

						<li class="top_li mr-lg-0"><span class="fa fa-envelope-o"></span><a href="mailto:witechict@gmail.com">Need help? Contact Us </a>

						</li>
						
					</ul>
				</div>
			</div>
		</div>

	</div>

</section>
<!--//top-header-content-->

<!--w3l-banner-slider-main-->
<section class="w3l-banner-slider-main w3l-inner-page-main">
    <div class="breadcrumb-infhny">
      <header class="top-headerhny">
        <!--/nav-->
        <nav class="navbar navbar-expand-lg navbar-light fill">
          <div class="container-fluid">
            <!-- <a class="navbar-brand" href="index.php">
              <label class="lohny"><span aria-hidden="true"></span>Wi</label>Tech</a> -->
              
              <a class="navbar-brand" href="index.php">
              <img src="assets/images/logo.png" alt="Whitechaple Institute Of Technology | A Whitechaple Global Company" title="Your logo" style="height:50px;" />
              </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse"
              data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
              aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
  
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mx-lg-auto ml-auto">
                <li class="nav-item active">
                  <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="about.php">About</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index.php#courses">Courses</a>
                </li>
  
  
                <li class="nav-item">
                  <a class="nav-link" href="contact.php">Contact</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="verify.php">Verify Student Certificate</a>
                </li>
              </ul>
  
            </div>
            <!-- <form action="#" method="post" class="d-flex searchhny-form">
              <input type="search" placeholder="Search Here..." required="required">
              <button type="submit"><span class="fa fa-search" aria-hidden="true"></span></button>
            </form> -->
          </div>
        </nav>
        <!--//nav-->
      </header>
    <!-- /breadcrumbs-->
    