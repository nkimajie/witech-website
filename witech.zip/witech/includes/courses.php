<section class="features-6">
  		<div class="features6-block py-5">
  			<div class="container py-lg-5">
  				<div class="row title-content">
  					<div class="col-lg-4 title-left">
  						<h3 class="hny-title">What We Provide</h3>
  					</div>
  					<!-- <div class="col-lg-8 title-info">
  						<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae eligendi minima
  							accusantium
  							reiciendis, cupiditate optio corrupti quis quam at!.Duis aute irure dolor in reprehenderit
  							in voluptate velit esse cillum.</p>
  					</div> -->
  				</div>
  				<div class="features6-grids text-center mt-5">
					<img src="assets/images/pic.jpg" class="img-fluid" alt="">

					<div class="three-grids d-grid grid-columns-3">
							<div class="grid">
								<div class="icon">
									<span class="fa fa-id-card-o" aria-hidden="true"></span>
								</div>
								<div class="icon-info">
									<h4><a href="#">Trusted Content</a></h4>
									<!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab sint consectetur quasi mollitia.</p> -->
								</div>			
							</div>
							<div class="grid">
								<div class="icon">
									<span class="fa fa-pencil-square-o" aria-hidden="true"></span>
								</div>
								<div class="icon-info">
									<h4><a href="#">Learning into Practice</a></h4>
									<!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab sint consectetur quasi mollitia.</p> -->
								</div>			
							</div>
							<div class="grid">
								<div class="icon">
									<span class="fa fa-graduation-cap" aria-hidden="true"></span>
								</div>
								<div class="icon-info">
									<h4><a href="#">
											Personalize Learning
											</a></h4>
									<!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab sint consectetur quasi mollitia.</p> -->
								</div>					
							</div>	
						</div>
  				</div>
  			</div>
  		</div>
  	</section>
  	<!-- features-4 -->

<section class="w3l-services-2">
	<!-- /content-6-section -->
	<div class="services-2-mian py-5">
		<div class="container py-lg-5">
			<div class="row title-content">
				<div class="col-lg-4 title-left">
					<h3 id="courses" class="hny-title">Our Courses</h3>
				</div>
				<div class="col-lg-8 title-info">
					<p>At Witech we offered good and quality services, to raise our costumers minds to a high pedestral 
									 in knowlage and increase skill set.</p>
				</div>
			</div>
			<div class="welcome-grids row">
				<div class="col-lg-4 col-md-6 course-grid">
					<div class="course-grid-inf">
						<a href="#"><img src="assets/images/a1.jpg" class="img-fuild" alt=""></a>
						<div class="course-content">
							<div class="course-info">
								<a href="#" class="course-titlegulp-wrapper">
									<h3 class="course-title">Infotech Proficiency</h3>
								</a>
							</div>
							
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 course-grid">

					<div class="course-grid-inf">
						<a href="#"><img src="assets/images/a2.jpg" class="img-fuild" alt=""></a>
						<div class="course-content">
							<div class="course-info">
								<a href="#" class="course-titlegulp-wrapper">
									<h3 class="course-title">Graphic Design</h3>
								</a>
							</div>
						</div>
					</div>

				</div>
				<div class="col-lg-4 col-md-6 course-grid">
					<div class="course-grid-inf">
						<a href="#"><img src="assets/images/a3.jpg" class="img-fuild" alt=""></a>
						<div class="course-content">
							<div class="course-info">
								<a href="#" class="course-titlegulp-wrapper">
									<h3 class="course-title">Mobile & App Development</h3>
								</a>
							</div>
						</div>
					</div>

				</div>
				<div class="col-lg-4 col-md-6 course-grid">
					<div class="course-grid-inf">
						<a href="#"><img src="assets/images/a4.jpg" class="img-fuild" alt=""></a>
						<div class="course-content">
							<div class="course-info">
								<a href="#" class="course-titlegulp-wrapper">
									<h3 class="course-title">Web Design | Development</h3>
								</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 course-grid">
					<div class="course-grid-inf">
						<a href="#"><img src="assets/images/a5.jpg" class="img-fuild" alt=""></a>
						<div class="course-content">
							<div class="course-info">
								<a href="#" class="course-titlegulp-wrapper">
									<h3 class="course-title">Networking</h3>
								</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 course-grid">
					<div class="course-grid-inf">
						<a href="#"><img src="assets/images/a6.jpg" class="img-fuild" alt=""></a>
						<div class="course-content">
							<div class="course-info">
								<a href="#" class="course-titlegulp-wrapper">
									<h3 class="course-title">Cyber Security</h3>
								</a>
							</div>
						</div>
					</div>
				</div>
            </div>
            <div class="welcome-grids row">
				<div class="col-lg-4 col-md-6 course-grid">
					<div class="course-grid-inf">
						<a href="#"><img src="assets/images/a7.jpg" class="img-fuild" alt=""></a>
						<div class="course-content">
							<div class="course-info">
								<a href="#" class="course-titlegulp-wrapper">
									<h3 class="course-title">Programming</h3>
								</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 course-grid">

					<div class="course-grid-inf">
						<a href="#"><img src="assets/images/a8.jpg" class="img-fuild" alt=""></a>
						<div class="course-content">
							<div class="course-info">
								<a href="#" class="course-titlegulp-wrapper">
									<h3 class="course-title">Blogging</h3>
								</a>
							</div>
						</div>
					</div>

				</div>
				<div class="col-lg-4 col-md-6 course-grid">
					<div class="course-grid-inf">
						<a href="#"><img src="assets/images/a9.jpg" class="img-fuild" alt=""></a>
						<div class="course-content">
							<div class="course-info">
								<a href="#" class="course-titlegulp-wrapper">
									<h3 class="course-title">Digital Marketing</h3>
								</a>
							</div>
						</div>
					</div>

				</div>
				<div class="col-lg-4 col-md-6 course-grid">
					<div class="course-grid-inf">
						<a href="#"><img src="assets/images/a10.jpg" class="img-fuild" alt=""></a>
						<div class="course-content">
							<div class="course-info">
								<a href="#" class="course-titlegulp-wrapper">
									<h3 class="course-title">Solar Energy</h3>
								</a>
							</div>
						</div>
					</div>
                </div>
                <div class="col-lg-4 col-md-6 course-grid">
					<div class="course-grid-inf">
						<a href="#"><img src="assets/images/a11.jpg" class="img-fuild" alt=""></a>
						<div class="course-content">
							<div class="course-info">
								<a href="#" class="course-titlegulp-wrapper">
									<h3 class="course-title">Inverter Technology</h3>
								</a>
							</div>
						</div>
					</div>

				</div>
				<div class="col-lg-4 col-md-6 course-grid">
					<div class="course-grid-inf">
						<a href="#"><img src="assets/images/a12.jpg" class="img-fuild" alt=""></a>
						<div class="course-content">
							<div class="course-info">
								<a href="#" class="course-titlegulp-wrapper">
									<h3 class="course-title">cctv</h3>
								</a>
							</div>
						</div>
					</div>
				</div>